from django.apps import AppConfig


class SwimrecordsConfig(AppConfig):
    name = 'swimrecords'
