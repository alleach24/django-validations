from django.db import models

class SwimRecord(models.Model):
    pass # delete me when you start writing in validations
    # first_name = models.CharField()
    # last_name = models.CharField()
    # team_name = models.CharField()
    # relay = models.BooleanField()
    # stroke = models.CharField()
    # distance = models.IntegerField()
    # record_date = models.DateTimeField()
    # record_broken_date = models.DateTimeField()
